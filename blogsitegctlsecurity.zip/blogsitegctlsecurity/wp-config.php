<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'blogsitegctlsecurity' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'lZIai_~e2Ej%`mkz3Pi;SRK%Qb[0yHeUv5UL#2M-;&B-Mg-}G9CGWD&P!ruH!!yU' );
define( 'SECURE_AUTH_KEY',  'DVfms1.mc307Zm]Z7wkn6b!/T;Nn2>,@3:HIo>>L2po*2xL$X6fiJu~8umH$b7lX' );
define( 'LOGGED_IN_KEY',    'zqkYy1gmZpEnh+xK{;%Q7/=Bb&Bch`+68$T2-KbOh>N=3*Z}!Fu/$Gej$_fszT$R' );
define( 'NONCE_KEY',        'F#ejb.`6`oJ-sQ8*4TNIa%y[Y+_ocfy_7SY=|/uQ%6w|#,3EKLo[LCY=%+4=CMVj' );
define( 'AUTH_SALT',        '3$1XSOh+yaRja.KmIhDGa-L8YPpjL:~{NH-.|Cox81=}c-%u{I6)M^!rKU#A5YRu' );
define( 'SECURE_AUTH_SALT', 'f<;oj52ikZeZ%3hiE?Ra/%hC>#I<?_{UALheGH;#?zU<-[V7}`Fb>HC^yWrx/C@<' );
define( 'LOGGED_IN_SALT',   'IqbNNC!q]yO!$ln*rDNgH2%O`$_]*.(n[~mL8Io;>skOh_G@de]^Q%O3gtP{`h&*' );
define( 'NONCE_SALT',       'Z{f{[9g!f]jd,H,~z~:qIr|[%@Y#ALWg3a+Y<Ffa_ZWvUiZ7g4U/n.K}r^B Q:~6' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', true );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
